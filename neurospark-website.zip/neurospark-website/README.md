# NeuroSpark Website

This is the static HTML website for the NeuroSpark puzzle book series. It includes:
- A mission statement
- Showcase of the 4-book series

## How to Use
You can deploy this site with GitHub Pages or any static hosting provider.

## Deployment
To deploy using GitHub Pages:
1. Push this code to your GitHub repository
2. Go to your repo's Settings > Pages
3. Select the main branch and root folder
4. Your site will be available at `https://<your-username>.github.io/<repo-name>/`